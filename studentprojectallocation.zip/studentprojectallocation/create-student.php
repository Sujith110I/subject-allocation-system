<?php require 'init.php'; ?>
<?php include 'head.php'; ?>
<body>
<?php include 'dashboard_navbar.php'; ?>
<h3>Add Student</h3>
<?php include 'createstd.php'; ?>
<?php include 'footer.php'; ?>