<?php
session_start();
include 'db.php';
include 'model.php';
define('PROJECT_NAME', 'Student Project Allocation & Management System');
